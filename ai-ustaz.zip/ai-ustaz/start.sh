#!/bin/bash

# 🎯 Скрипт запуска Flashcards Flask App

# Цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}🚀 Запуск Flashcards Flask приложения...${NC}"

# Переходим в директорию скрипта
cd "$(dirname "$0")"

# Проверка наличия .env файла
if [ ! -f .env ]; then
    echo -e "${RED}❌ Файл .env не найден!${NC}"
    exit 1
fi

# Загружаем переменные из .env
echo -e "${YELLOW}📂 Загрузка переменных из .env...${NC}"
export $(cat .env | grep -v '^#' | xargs)

# Проверка API ключа
if [ -z "$GEMINI_API_KEY" ]; then
    echo -e "${RED}❌ GEMINI_API_KEY не найден в .env файле!${NC}"
    exit 1
fi

echo -e "${GREEN}✅ API ключ загружен (длина: ${#GEMINI_API_KEY} символов)${NC}"

# Проверка наличия Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python3 не установлен!${NC}"
    exit 1
fi

# Установка порта (по умолчанию 8000)
PORT=${PORT:-8000}

echo -e "${GREEN}🌐 Запуск на порту ${PORT}...${NC}"
echo -e "${YELLOW}📍 ai-ustaz: $(pwd)${NC}"
echo ""
echo -e "${GREEN}✨ Приложение запущено!${NC}"
echo -e "${GREEN}🔗 Откройте: http://localhost:${PORT}${NC}"
echo -e "${YELLOW}⏹️  Для остановки нажмите Ctrl+C${NC}"
echo ""

# Запуск Flask
python3 flashcards.py