#!/bin/bash

echo "🛑 Остановка Flashcards..."

# Найти и убить процесс
pkill -f "python3 flashcards.py"

if [ $? -eq 0 ]; then
    echo "✅ Приложение остановлено"
else
    echo "⚠️  Процесс не найден (возможно уже остановлен)"
fi