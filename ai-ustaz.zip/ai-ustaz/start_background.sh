#!/bin/bash

# 🔧 Запуск в фоновом режиме

cd "$(dirname "$0")"

# Проверка .env
if [ ! -f .env ]; then
    echo "❌ Файл .env не найден!"
    exit 1
fi

# Загрузка переменных
export $(cat .env | grep -v '^#' | xargs)

# Проверка API ключа
if [ -z "$GEMINI_API_KEY" ]; then
    echo "❌ GEMINI_API_KEY не найден!"
    exit 1
fi

PORT=${PORT:-8000}

echo "🚀 Запуск в фоновом режиме..."
echo "📝 Логи: flashcards.log"

# Запуск в фоне с записью логов
nohup python3 flashcards.py > flashcards.log 2>&1 &

PID=$!
echo "✅ Запущено! PID: $PID"
echo "🔗 URL: http://localhost:${PORT}"
echo ""
echo "📋 Полезные команды:"
echo "   Просмотр логов: tail -f flashcards.log"
echo "   Остановка: kill $PID"
echo "   Проверка: ps aux | grep flashcards"